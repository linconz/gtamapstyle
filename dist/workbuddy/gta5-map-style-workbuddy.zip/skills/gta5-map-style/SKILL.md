---
name: gta5-map-style
display_name: "GTA 5 城市地图"
display_name_en: "GTA 5 City Map"
description: "使用 OpenFreeMap 和 OpenStreetMap 的真实地图与地点数据，将任意现实城市导出为无地图文字、无城市标题、精确 3000×3000 的 GTA 5 风格 PNG，支持自然语言范围控制和同步导出同范围的 OFM 原图。适用于用户显式调用 gta5-map-style 技能，或要求制作 GTA 5 风格城市地图、黑底灰白道路地图、带 GTA 5 地点图标的真实城市地图时。"
description_zh: "使用真实 OpenFreeMap 与 OpenStreetMap 数据生成精确 3000×3000 的 GTA 5 风格城市地图，并支持自然语言范围控制和同范围 OFM 对照图。"
description_en: "Generate an exact 3000×3000 GTA 5-style map from real OpenFreeMap and OpenStreetMap data, with natural-language area control and an optional matching OFM reference image."
version: "1.0.0"
author: "linconz"
allowed-tools: "Bash"
disable-model-invocation: false
user-invocable: true
---
# GTA 5 城市地图

将用户指定的真实城市导出为成品 PNG。底图使用黑色地面、灰白分级道路和低饱和蓝色水域；地点图标只使用本技能内置的 GTA 5 blip PNG。

## 工作流程

1. 从请求中提取城市和可选范围描述。没有城市时先询问城市名；城市有重名且无法唯一解析时，要求用户补充省份、州或国家。
2. 将本 `SKILL.md` 所在目录作为技能根目录。若 `node_modules` 不存在，在技能根目录执行 `npm ci --omit=dev`。
3. 城市定位优先使用 Nominatim，地点数据使用 Overpass，底图使用 OpenFreeMap 的 OpenMapTiles 矢量瓦片。若 Nominatim 明确因 DNS、连接或超时而不可用，并且模型能可靠给出对应城市的 WGS84 中心经纬度，则使用模型中的坐标作为城市定位降级结果；不要把“无匹配结果”或城市重名当作网络故障，也不要臆测不确定的坐标或行政边界。
4. 若用户未指定输出路径，在当前工作区使用 `outputs/<city>-gta5-map-3000.png`。向脚本传入绝对路径。
5. 在技能根目录运行：

   ```text
   node scripts/export-city-map.mjs \
     --city "<城市, 国家>" \
     --output "<绝对输出路径>" \
     --language "zh-CN"
   ```

   - 第一次运行因 Nominatim 网络不可用而失败时，若能可靠确定城市中心坐标，使用 `--latitude <WGS84 纬度> --longitude <WGS84 经度>` 重新运行。脚本会跳过 Nominatim 城市解析，将该中心传给 Overpass 地点查询和 OpenFreeMap 渲染；不要手工改写缓存。该降级只提供城市中心，不提供行政边界。环路范围仍可由 Overpass 解析，其他行政区或地标范围如果仍需 Nominatim 且无法解析，应明确说明后停止，不得忽略用户指定的范围。
   - 用户描述了行政区、环路、城区或地标范围时，添加 `--scope "<城市与范围>"`。例如“香港九龙及港岛北岸”传入 `--scope "九龙、香港岛北岸"`。用户列出多个行政区时，先纠正明显错别字并使用正式行政区名称，再以 `、` 分隔后传给同一个 `--scope`；脚本取这些边界的联合范围。
   - 用户给出最小与最大跨度时，分别添加 `--min-range-km <公里>` 和 `--max-range-km <公里>`。脚本以范围边界的中心和最大边长为基准，在上下限之间选择适中的画面跨度；不自行把上下限解释为缩放级别。
   - 用户说“同时导出 OFM 原图”“附带 OpenFreeMap 对照图”或同义表述时，添加 `--include-ofm-original`。若用户指定原图保存位置，再添加 `--ofm-output "<绝对 PNG 路径>"`。OFM 原图必须与 GTA 成品使用完全相同的中心、缩放、地理范围、3256×3256 渲染视口和四周 128 像素裁切，最终同为 3000×3000。
   - 只有用户要求另一套可复现地点布局时才添加 `--seed "<种子>"`。只有用户明确同意覆盖既有文件时才添加 `--force`。
6. 成功后确认输出为严格 3000×3000 PNG，并向用户提供可点击文件链接或图片预览。

## 成品约束

- 保持纯地图画面，不添加 GTA 标志、城市标题、地图文字、地点名称或风险提示。
- GTA 成品和 OFM 原图都要裁掉右下角底部提示，不保留地图控件或可视署名；不要添加合同、来源或风险文字。
- 不使用 Better Icons，不自行替换内置地点图标。
- 地点必须来自 OpenStreetMap 的真实数据；结果不足时减少图标，不伪造、不重复地点。
- 夜总会、夜店和脱衣舞俱乐部统一使用高跟鞋 `radar_strip_club`，不得使用 `radar_music_venue`；酒吧继续使用 `radar_bar`。银行使用 `radar_finale_bank_heist` 并固定渲染为浅奶油黄。家的 `radar_safehouse` 只将原图白色主体映射为参考图绿色 `#28DB05`，必须保留黑色窗户和内部线条。车辆修理厂、仓库、办公室、改装车、理发店、医院、游乐场和高尔夫球场使用各自对应的 GTA 5 blip。
- 用枪店、纹身店、赌场、夜总会、赛车场、射击场、码头与游艇、直升机坪、洗车场、网球场、游戏厅和汽车展厅等活动类图标增强 GTA 游戏氛围；每个图标仍必须对应真实 OSM 地点。
- 只有机场显示画面范围内的全部真实结果，不应用随机目标数、同类间距或全局稀疏规则。
- 火车站不包含地铁、轻轨站和地铁入口，并与所有非机场类别一样最多读取 20 个候选点，由稳定种子选择 2 或 3 个；同类图标至少相距 360 像素，全局至少相距 110 像素，距离成品边缘至少 100 像素。
- 范围描述优先于城市行政边界。环路范围优先解析 OSM 道路边界；多个行政区取各自真实边界的联合边界框；其他范围使用对应行政区或地标的边界框。最小范围默认 15 公里，最大范围默认 80 公里。
- 不保存 Overpass 原始响应、地点名称或中间地点数据。Nominatim 只缓存规范化城市定位结果。
- 脚本失败时不得把临时截图当作成品交付。

## 环境问题

Nominatim 不可用时先按上述 WGS84 城市中心坐标降级流程处理。模型无法可靠确定坐标，或运行时、Chrome、OpenFreeMap、Overpass 不可用时，读取 [OpenFreeMap 与 OpenStreetMap 环境](references/openstreetmap-setup.md)，指出最短修复步骤后停止。不要替换为其他地图平台。
